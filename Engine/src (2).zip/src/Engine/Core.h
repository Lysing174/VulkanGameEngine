#pragma once
#define FMT_HEADER_ONLY

#ifdef EG_PLATFORM_WINDOWS
	#ifdef  EG_BUILD_DLL
		#define ENGINE_API __declspec(dllexport)
	#else
		#define ENGINE_API __declspec(dllimport)
	#endif
#else
	#error Vulkan Engine only support Windows!
#endif //  EG_BUILD_DLL

#define BIT(x) (1 << x)