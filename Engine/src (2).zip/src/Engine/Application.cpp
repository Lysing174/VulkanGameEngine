#include "Application.h"

#include "Events/ApplicationEvent.h"
#include "Log.h"

#include <sstream>
#include "spdlog/fmt/ostr.h"

namespace Engine {
	Application::Application()
	{}
	Application::~Application() {}
	void Application::Run()
	{
		WindowResizeEvent e(1200, 720);
		EG_TRACE(e);
		std::stringstream ss;
		ss << e;
		while (true)
		{

		}
	}
}